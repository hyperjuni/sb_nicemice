﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

namespace colorGenerator
{
    class Program
    {
        private static String ToHex(System.Drawing.Color c)
       => $"{c.R:X2}{c.G:X2}{c.B:X2}";

        static void Main(string[] args)
        {
            Bitmap myBitmap = new Bitmap("palette.png");
            List<String> lines = new List<string>();

            //every row is 8 pixels representing 2 palettes that need to be formatted correctly:
            /*
                "1" : "aaaaaa", "2" : "bbbbbb", "3" : "cccccc", "4" : "dddddd",
                "5" : "eeeeee", "6" : "ffffff", "7" : "gggggg", "8" : "hhhhhh"

                1/2/3/4/5/6/7/8 will always be the same values, 
                and the values from our rows of pixels get fed into the a/b/c/d/e/f/g
            */

            int rows = myBitmap.Height;
            int cols = myBitmap.Width;
            List<String> baseColors = new List<String>() { "_A", "_B", "_C", "_D", "_E", "_F", "_G", "_H" };
            int i_r = 0;
            for(i_r = 0; i_r < rows; ++i_r)
            {
                String rowStr = "{ \"_A\" : \"_1\", \"_B\" : \"_2\", \"_C\" : \"_3\", \"_D\" : \"_4\", \"_E\" : \"_5\", \"_F\" : \"_6\", \"_G\" : \"_7\", \"_H\" : \"_8\" },";
                rowStr = rowStr.Replace("_A", baseColors[0]);
                rowStr = rowStr.Replace("_B", baseColors[1]);
                rowStr = rowStr.Replace("_C", baseColors[2]);
                rowStr = rowStr.Replace("_D", baseColors[3]);
                rowStr = rowStr.Replace("_E", baseColors[4]);
                rowStr = rowStr.Replace("_F", baseColors[5]);
                rowStr = rowStr.Replace("_G", baseColors[6]);
                rowStr = rowStr.Replace("_H", baseColors[7]);

                int i_c = 0;
                for (i_c = 0; i_c < cols; ++i_c)
                {
                    Color p = myBitmap.GetPixel((cols-1)-i_c, i_r);
                    String colStr = ToHex(p);
                    if (i_r > 0)
                        rowStr = rowStr.Replace("_" + (i_c + 1).ToString(), colStr);
                    else
                    {
                        baseColors[i_c] = colStr;
                        //lines.Add(colStr);
                    }
                }

                if(i_r > 0)
                lines.Add(rowStr);
            }
            //lines.Add("---");
            //lines.Add(baseColors.ToString());
            File.WriteAllLines("output.txt", lines);

            generateMice();
            generatePaletteBrightness();
        }

        public static float CalculateBrightness(int r, int g, int b)
        {
            float R = r * r;
            float G = g * g;
            float B = b * b;
            return (float)Math.Sqrt(0.299 * R + 0.587 * G + 0.114 * B);
        }

        private static void generatePaletteBrightness()
        {
            //load the palette
            Bitmap palette = new Bitmap("paletteskin.png");
            PixelFormat format = palette.PixelFormat;

            Bitmap output = new Bitmap(palette);
            int x, y;
            for (y = 0; y < output.Height; ++y)
            {
                for (x = 0; x < output.Width; ++x)
                {
                    Color p = output.GetPixel(x, y);
                    int bright = (int)CalculateBrightness(p.R, p.G, p.B);
                    
                    //should never happen but float math is stupid sometimes
                    if (bright > 255)
                        bright = 255;
                    if (bright < 0)
                        bright = 0;

                    Color col = Color.FromArgb(255, bright, bright, bright);
                    output.SetPixel(x, y, col);
                }
            }
            output.Save("palettebrightness.png", ImageFormat.Png);
        }

        private static void generateMice()
        {
            //clear the mouse directory
            System.IO.DirectoryInfo di = new DirectoryInfo("./mouseoutput");
            foreach (FileInfo file in di.GetFiles())
            {file.Delete();}
            foreach (DirectoryInfo dir in di.GetDirectories())
            {dir.Delete(true);}

            //load the palette
            Bitmap palette = new Bitmap("paletteskin.png");
            PixelFormat format = palette.PixelFormat;

            //load the templates
            Bitmap head = new Bitmap("./mouseparts/femalehead.png");
            Bitmap bodyf = new Bitmap("./mouseparts/femalebody.png");
            Bitmap bodym = new Bitmap("./mouseparts/malebody.png");
            Bitmap armf = new Bitmap("./mouseparts/frontarm.png");
            Bitmap armb = new Bitmap("./mouseparts/backarm.png");
            Bitmap tail = new Bitmap("./mouseparts/tail.png");
            Bitmap templatef = new Bitmap("./mouseparts/templatef.png");
            Bitmap templatem = new Bitmap("./mouseparts/templatem.png");

            //set up rects for image slicing
            Rectangle headRect = new Rectangle();
            headRect.Width = 43;
            headRect.Height = 43;
            headRect.X = 43;
            headRect.Y = 0;

            List<int> headBobOffsets = new List<int>() { 0, -1, 0, 1, 0, -1, 0, 1 };

            List<Rectangle> armFrameRects = new List<Rectangle>();
            List<Rectangle> walkFrameRects = new List<Rectangle>();

            //set up arm frames
            int rbx = 0;
            for (rbx = 0; rbx < 5; ++rbx)
            {
                Rectangle rect = new Rectangle();
                rect.Width = 43;
                rect.Height = 43;
                rect.X = 86 + 43 * rbx;
                rect.Y = 43;
                armFrameRects.Add(rect);
            }
            List<int> armFrameCycle = new List<int>() { 1, 0, 1, 2, 3, 4, 3, 2 };

            //set up walk frames
            for (rbx = 0; rbx < 8; ++rbx)
            {
                Rectangle rect = new Rectangle();
                rect.Width = 43;
                rect.Height = 43;
                rect.X = 43 + 43 * rbx;
                rect.Y = 43;
                walkFrameRects.Add(rect);
            }

            List<Bitmap> ears = new List<Bitmap>();
            di = new DirectoryInfo("./mouseparts/ears");
            foreach (FileInfo file in di.GetFiles())
            {
                Bitmap b = new Bitmap(file.FullName);
                ears.Add(b);
            }
            List<Bitmap> hairstyles = new List<Bitmap>();
            di = new DirectoryInfo("./mouseparts/hair");
            foreach (FileInfo file in di.GetFiles())
            {
                Bitmap b = new Bitmap(file.FullName);
                hairstyles.Add(b);
            }

            Random randrand = new Random();

            //generate 20 mice walk cycles
            int iterations = 32;
            int iteration = 0;

            int prevPaletteIndex = 9001;
            int prevEarStyle = 9001;
            int prevHairStyle = 9001;

            for (iteration = 0; iteration < iterations; ++iteration)
            {
                //choose a palette - disallow same bracket
                int chosenPaletteIndex = (randrand.Next() % (palette.Height -1)) + 1;
                while(Math.Abs(chosenPaletteIndex - prevPaletteIndex) < 20)
                    chosenPaletteIndex = (randrand.Next() % (palette.Height - 1)) + 1;
                prevPaletteIndex = chosenPaletteIndex;

                //choose an ear style - make sure it is not the same one as last time
                int chosenEarStyle = randrand.Next() % ears.Count;
                while(chosenEarStyle == prevEarStyle)
                    chosenEarStyle = randrand.Next() % ears.Count;
                prevEarStyle = chosenEarStyle;
                
                //choose a hair style - make sure the distance is at least 2-away
                int chosenHairStyle = randrand.Next() % hairstyles.Count;
                while (Math.Abs(chosenHairStyle - prevHairStyle) < 2)
                    chosenHairStyle = randrand.Next() % hairstyles.Count;
                prevHairStyle = chosenHairStyle;

                //the second ten should be male
                bool isMale = (iteration >= (iterations/2));

                //the last one should look like ori
                bool applyOriEyes = false;
                if (iteration == (iterations - 1))
                {
                    chosenPaletteIndex = 1;
                    chosenEarStyle = 11;
                    chosenHairStyle = 11;
                    applyOriEyes = true;
                }

                int frames = 8;
                int frame = 0;
                for (frame = 0; frame < frames; ++frame)
                {
                    Bitmap result = new Bitmap(43, 43);
                    int bx, by;

                    //crop the back arm frame
                    Bitmap backArmBlit = armb.Clone(armFrameRects[armFrameCycle[frame]], format);
                    //blit it
                    for (by = 0; by < 43; ++by) { for (bx = 0; bx < 43; ++bx) { Color p = backArmBlit.GetPixel(bx, by); if(p.A > 0) result.SetPixel(bx, by, p); } }

                    //crop the current tail frame
                    Bitmap tailBlit = tail.Clone(walkFrameRects[frame], format);
                    //blit it
                    for (by = 0; by < 43; ++by) { for (bx = 0; bx < 43; ++bx) { Color p = tailBlit.GetPixel(bx, by); if (p.A > 0) result.SetPixel(bx, by - headBobOffsets[frame], p); } }

                    //crop the head
                    Bitmap headBlit = head.Clone(headRect, format);
                    //blit it
                    for (by = 0; by < 43; ++by) { for (bx = 0; bx < 43; ++bx) { Color p = headBlit.GetPixel(bx, by); if (p.A > 0) result.SetPixel(bx, by - headBobOffsets[frame], p); } }

                    //crop the chosen ear style
                    Bitmap earsBlit = ears[chosenEarStyle].Clone(headRect, format);
                    //blit it
                    for (by = 0; by < 43; ++by) { for (bx = 0; bx < 43; ++bx) { Color p = earsBlit.GetPixel(bx, by); if (p.A > 0) result.SetPixel(bx, by - headBobOffsets[frame], p); } }

                    //crop the chosen hair style
                    Bitmap hairBlit = hairstyles[chosenHairStyle].Clone(headRect, format);
                    //blit it
                    for (by = 0; by < 43; ++by) { for (bx = 0; bx < 43; ++bx) { Color p = hairBlit.GetPixel(bx, by); if (p.A > 0) result.SetPixel(bx, by - headBobOffsets[frame], p); } }

                    //crop the current walk frame
                    Bitmap walkBlit;
                    if( isMale == false)
                        walkBlit = bodyf.Clone(walkFrameRects[frame], format);
                    else
                        walkBlit = bodym.Clone(walkFrameRects[frame], format);
                    //blit it
                    for (by = 0; by < 43; ++by) { for (bx = 0; bx < 43; ++bx) { Color p = walkBlit.GetPixel(bx, by); if (p.A > 0) result.SetPixel(bx, by, p); } }

                    //crop the current front arm frame
                    Bitmap frontArmBlit = armf.Clone(armFrameRects[armFrameCycle[frame]], format);
                    //blit it
                    for (by = 0; by < 43; ++by) { for (bx = 0; bx < 43; ++bx) { Color p = frontArmBlit.GetPixel(bx, by); if (p.A > 0) result.SetPixel(bx, by, p); } }

                    //apply current palette
                    for (by = 0; by < 43; ++by)
                    {
                        for (bx = 0; bx < 43; ++bx)
                        {
                            Color p = result.GetPixel(bx, by);
                            int swapIndex;
                            for (swapIndex = 0; swapIndex < 8; ++swapIndex)
                            {
                                if (p == palette.GetPixel(swapIndex, 0))
                                    result.SetPixel(bx, by, palette.GetPixel(swapIndex, chosenPaletteIndex));

                                //default eye behavior, make color consistent
                                if (applyOriEyes == false)
                                {
                                    if (p == Color.FromArgb(255, 50, 50, 65))
                                    {
                                        result.SetPixel(bx, by, Color.FromArgb(255,51,50,65));
                                    }
                                    if (p == Color.FromArgb(255, 49, 50, 65))
                                    {
                                        result.SetPixel(bx, by, Color.FromArgb(255, 51, 50, 65));
                                    }
                                }
                                //ori eye behavior, apply eye palette changes
                                else
                                {
                                    if (p == Color.FromArgb(255, 50, 50, 65))
                                    {
                                        result.SetPixel(bx, by, Color.FromArgb(255, 235, 216, 242));
                                    }
                                    if 
                                    (
                                        (p == Color.FromArgb(255, 49, 50, 65))||
                                        (p == Color.FromArgb(255, 0, 229, 170))||
                                        (p == Color.FromArgb(255, 0, 173, 128))
                                    )
                                    {
                                        result.SetPixel(bx, by, Color.FromArgb(255, 72, 47, 85));
                                    }
                                }
                            }
                        }
                    }

                    //outliner
                    for (by = 0; by < 43 * 1; ++by)
                    {
                        for (bx = 0; bx < 43 * 1; ++bx)
                        {
                            Color p = result.GetPixel(bx, by);
                            if ((p.A > 0) && (!((p.R == 0) && (p.G == 0) && (p.B == 0))))
                            {
                                int px, py;
                                List<int> offsets = new List<int>() { -1, 0, 1 };
                                for (py = 0; py < 3; ++py)
                                {
                                    for (px = 0; px < 3; ++px)
                                    {
                                        try
                                        {
                                            Color p1 = result.GetPixel(bx + offsets[px], by + offsets[py]);
                                            if (p1.A <= 0)
                                            {
                                                try
                                                {
                                                    if(! ((offsets[px] != 0) && (offsets[py] != 0)))
                                                    result.SetPixel(bx + offsets[px], by + offsets[py], Color.Black);
                                                }
                                                catch (System.ArgumentOutOfRangeException e)
                                                { }
                                            }
                                        }
                                        catch (System.ArgumentOutOfRangeException e)
                                        { }
                                    }
                                }
                            }
                        }
                    }

                    int scaleFactor = 4;
                    Bitmap resized = new Bitmap(result.Width * scaleFactor, result.Height * scaleFactor);
                    for (by = 0; by < 43; ++by)
                    {
                        for (bx = 0; bx < 43; ++bx)
                        {
                            int byy = 0;
                            for (byy = 0; byy < scaleFactor; ++byy)
                            {
                                int bxx = 0;
                                for (bxx = 0; bxx < scaleFactor; ++bxx)
                                {
                                    resized.SetPixel((bx * scaleFactor) + bxx, (by * scaleFactor) + byy, result.GetPixel(bx, by));
                                }
                            }
                        }
                    }

                    if (true)
                    {
                        /*
                         * for (by = 0; by < 43 * scaleFactor; ++by)
                        {
                            for (bx = 0; bx < 43 * scaleFactor; ++bx)
                            {
                                Color p = resized.GetPixel(bx, by);
                                if ((p.A > 0) && (p.R > 0) && (p.G > 0) && (p.B > 0))
                                {
                                    int px, py;
                                    List<int> offsets = new List<int>() { -1, 0, 1 };
                                    for (py = 0; py < 3; ++py)
                                    {
                                        for (px = 0; px < 3; ++px)
                                        {
                                            try
                                            {
                                                Color p1 = resized.GetPixel(bx + offsets[px], by + offsets[py]);
                                                if (p1.A <= 0)
                                                {
                                                    try
                                                    {
                                                        resized.SetPixel(bx + offsets[px], by + offsets[py], Color.Black);
                                                    }
                                                    catch (System.ArgumentOutOfRangeException e)
                                                    { }
                                                }
                                            }
                                            catch (System.ArgumentOutOfRangeException e)
                                            { }
                                        }
                                    }
                                }
                            }
                        }
                        */
                        
                        Bitmap finalized = new Bitmap(200, 200);
                        if (isMale == false)
                            {for (by = 0; by < 200; ++by) { for (bx = 0; bx < 200; ++bx) { Color p = templatef.GetPixel(bx, by); if (p.A > 0) finalized.SetPixel(bx, by, p); } }}
                        else
                            {for (by = 0; by < 200; ++by) { for (bx = 0; bx < 200; ++bx) { Color p = templatem.GetPixel(bx, by); if (p.A > 0) finalized.SetPixel(bx, by, p); } }}

                        for (by = 0; by < 43 * scaleFactor; ++by) { for (bx = 0; bx < 43 * scaleFactor; ++bx) { Color p = resized.GetPixel(bx, by); if (p.A > 0) try { finalized.SetPixel(bx - 28, by + 24, p); } catch (System.ArgumentOutOfRangeException e) { } } }
                        finalized.Save("./mouseoutput/" + iteration.ToString() + "_" + frame.ToString() + ".png", ImageFormat.Png);
                    }

                    //resized.Save("./mouseoutput/" + iteration.ToString() + "_" + frame.ToString() + ".png", ImageFormat.Png);
                }
            }
        }
    }
}
