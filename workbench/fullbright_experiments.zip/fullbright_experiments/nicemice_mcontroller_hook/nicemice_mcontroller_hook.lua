require "/scripts/nicemice_util.lua"

function init()
	--listen for incoming messages from players that want to subscribe to updates from this hook
	message.setHandler
	(
		--cazhe me outzide how bout zat
		"nicemice_mcontroller_subscribeMe",
		function(_,_,a)
			registerInterestedParty(a._senderId)
		end
	)
	
	script.setUpdateDelta(1)
end

--list of player entity ids that should be notified if any of our stuff changes
interestedParties = {}

function registerInterestedParty(id)
	--sb.logInfo("Registering " .. id .. " to feed for " .. entity.id())
	for k, v in ipairs(interestedParties) do
		if v == id then
			--sb.logInfo("Dumping duplicate registration request")
			return nil
		end
	end
	--sb.logInfo("registered")
	table.insert(interestedParties, id)
end

function unregisterInterestedParty(id)
	for k, v in ipairs(interestedParties) do
		if v == id then
			table.remove(interestedParties, k)
			break
		end
	end
end

--mcontroller hook data object
lastKnownConfiguration = {}

function update(dt)

	--grab from status controller if empty
	if #lastKnownConfiguration <= 0 then 
		lastKnownConfiguration = status.statusProperty("nicemice_mcontroller")
	end

	--grab the info we need for fullbright animator
	local facingDirection = mcontroller.facingDirection()
	local walking = mcontroller.walking()
	local running = mcontroller.running()
	local jumping = mcontroller.jumping()
	local falling = mcontroller.falling()
	local crouching = mcontroller.crouching()
	local onGround = mcontroller.onGround()
	local groundMovement = mcontroller.groundMovement()
	local liquidMovement = mcontroller.liquidMovement()
	local canJump = mcontroller.canJump()
	local velocity = mcontroller.velocity()
	
	--populate properties list
	local properties = {}
	properties["_facingDirection"] = facingDirection
	properties["_walking"] = walking
	properties["_running"] = running
	properties["_jumping"] = jumping
	properties["_falling"] = falling
	properties["_crouching"] = crouching
	properties["_onGround"] = onGround
	properties["_groundMovement"] = groundMovement
	properties["_liquidMovement"] = liquidMovement
	properties["_canJump"] = canJump
	properties["_velocity"] = velocity
	
	--we only want to call setStatusProperty if something actually changed
	
	local shouldUpdate = false
	
	--not same number params, update
	if #lastKnownConfiguration ~= #properties then
		shouldUpdate = true
		
	--same number params
	else
		--iterate each key, assume parity
		for k, v in pairs(properties) do
			if lastKnownConfiguration[k] ~= v then
				shouldUpdate = true
				break
			end
		end
	end
	
	if shouldUpdate then
		lastKnownConfiguration = properties
		status.setStatusProperty( "nicemice_mcontroller", properties )
		local id = entity.id()
		for k, targetId in ipairs(interestedParties) do
			if world.entityExists(targetId) then
				world.sendEntityMessage(targetId, "nicemice_mcontroller_cacheme", { _entityId = id, _mcontroller = properties } )
			else
				unregisterInterestedParty(targetId)
			end
		end
	end
end

function uninit()
end
