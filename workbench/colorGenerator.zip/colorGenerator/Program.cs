﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.IO;

namespace colorGenerator
{
    class Program
    {
        private static String ToHex(System.Drawing.Color c)
       => $"{c.R:X2}{c.G:X2}{c.B:X2}";

        static void Main(string[] args)
        {
            Bitmap myBitmap = new Bitmap("palette.png");
            List<String> lines = new List<string>();

            //every row is 8 pixels representing 2 palettes that need to be formatted correctly:
            /*
                "1" : "aaaaaa", "2" : "bbbbbb", "3" : "cccccc", "4" : "dddddd",
                "5" : "eeeeee", "6" : "ffffff", "7" : "gggggg", "8" : "hhhhhh"

                1/2/3/4/5/6/7/8 will always be the same values, 
                and the values from our rows of pixels get fed into the a/b/c/d/e/f/g
            */

            int rows = myBitmap.Height;
            int cols = myBitmap.Width;
            List<String> baseColors = new List<String>() { "_A", "_B", "_C", "_D", "_E", "_F", "_G", "_H" };
            int i_r = 0;
            for(i_r = 0; i_r < rows; ++i_r)
            {
                String rowStr = "{ \"_A\" : \"_1\", \"_B\" : \"_2\", \"_C\" : \"_3\", \"_D\" : \"_4\", \"_E\" : \"_5\", \"_F\" : \"_6\", \"_G\" : \"_7\", \"_H\" : \"_8\" },";
                rowStr = rowStr.Replace("_A", baseColors[0]);
                rowStr = rowStr.Replace("_B", baseColors[1]);
                rowStr = rowStr.Replace("_C", baseColors[2]);
                rowStr = rowStr.Replace("_D", baseColors[3]);
                rowStr = rowStr.Replace("_E", baseColors[4]);
                rowStr = rowStr.Replace("_F", baseColors[5]);
                rowStr = rowStr.Replace("_G", baseColors[6]);
                rowStr = rowStr.Replace("_H", baseColors[7]);

                int i_c = 0;
                for (i_c = 0; i_c < cols; ++i_c)
                {
                    Color p = myBitmap.GetPixel((cols-1)-i_c, i_r);
                    String colStr = ToHex(p);
                    if (i_r > 0)
                        rowStr = rowStr.Replace("_" + (i_c + 1).ToString(), colStr);
                    else
                    {
                        baseColors[i_c] = colStr;
                        //lines.Add(colStr);
                    }
                }

                if(i_r > 0)
                lines.Add(rowStr);
            }
            //lines.Add("---");
            //lines.Add(baseColors.ToString());
            File.WriteAllLines("output.txt", lines);
        }
    }
}
