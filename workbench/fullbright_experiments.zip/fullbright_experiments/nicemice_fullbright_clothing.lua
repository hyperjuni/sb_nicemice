require "/scripts/vec2.lua"
require "/scripts/nicemice_util.lua"

local _init = init
local _update = update
local _uninit = uninit

function init()
	_init()
	
	--hook our mcontroller
	status.setPersistentEffects("nicemice_mcontroller_hook", {"nicemice_mcontroller_hook"})
	
	--initialize the fullbright component cache for the player
	--TODO need a dedicated func for setting up a cache entry
	entityFullbrightComponentsCache[player.id()] = 
	{
		_mcontroller = status.statusProperty("nicemice_mcontroller"),
		_lastKnownAnimationState = "idle",
		_timeSpentInCurrentAnimation = 0
	}
	
	--listen for updates from our mcontroller hook for when we need to re-cache so we're not spamming it in multiplayer
	message.setHandler
	(
		--cazhe me outzide how bout zat
		"nicemice_mcontroller_cacheme",
		function(_,_,a)
			cacheMController(a)
		end
	)
	
	message.setHandler
	(
		"nicemice_npcItemsReply",
		function(_,_,a)
			cacheNPCItems(a)
		end
	)
	
	script.setUpdateDelta(1)
	
end

--some constants for various animation states
local STATE_WALK = "walk"
local STATE_RUN = "run"
local STATE_IDLE = "idle"
local STATE_CROUCH = "crouch"
local STATE_JUMP = "jump"
local STATE_JUMP_CREST = "crest"
local STATE_FALL = "fall"
local STATE_SIT = "sit"
local STATE_SWIM_IDLE = "swimidle"
local STATE_SWIM = "swim"
local STATE_UNKNOWN = "howdidthisgethereiamnotgoodwithcomputer"

--converts a movement controller hook and entity id into one of the state labels above
function inferCurrentStateFromMovementController(mc, id)

	-- TODO - need a proper hook for player and npc lounging
	--		unable to call player or npc from the motioncontroller hook. argh
	--
	--  if mc._isLounging == true then
	--  	return STATE_SIT
	--  end
	--  
	--  if mc.isLounging == "player" then
	--  	if player.isLounging() then
	--  		return STATE_SIT
	--  	end
	--  end
	
	--the jumping flag has higher prio than being on the ground or in the water
	--this looks unintuitive and stupid because it is, but that's not my fault
	
	if mc._jumping then
		if mc._liquidMovement then
			return STATE_SWIM
		end
		return STATE_JUMP
	end
	
	if mc._falling then
		if mc._liquidMovement then
			return STATE_SWIM_IDLE
		end
		return STATE_FALL
	end
	
	--at the top of a jump with no upward or downward velocity is its own weird quasi-state I guess
	if (not mc._onGround) and (not mc._jumping) and (not mc._falling) and (not mc._liquidMovement) and (not mc._canJump) then
		return STATE_JUMP_CREST
	end
	
	--if we make it this far and we're in liquid then we're playing swim idle
	if mc._liquidMovement then
		--just kidding
		if mc._onGround then
			if mc._running then
				return STATE_RUN
			end
			if mc._walking then
				return STATE_WALK
			end
			if mc._crouching then
				return STATE_CROUCH
			end
		else
			return STATE_SWIM_IDLE
		end
	end
	
	if mc._running then
		return STATE_RUN
	end
	if mc._walking then
		return STATE_WALK
	end
	if mc._crouching then
		return STATE_CROUCH
	end
	
	return STATE_IDLE
end

--to figure out which frame to play in an animation,
--we calculate how long the animation takes to play per frame,
--and then use that to figure out which frame we should be on based on how long we've been in the state

--this seems like a very weird way to do things,
--but in the game's source code it looks like it's set up this way, too
--or at least that's what it looked like, idk, go look at StarHumanoid.cpp for yourself

function inferCurrentFrameFromTimeSpentInAnimationState(anim, timeSpent)
	--timings from the humanoid config are probably consistent across all species
	--but this is nicemice tech so if it breaks for someone else it's not my problem
	local anims = {}
	
	anims[STATE_WALK] = {}
		anims[STATE_WALK]["timing"] = 0.75
		anims[STATE_WALK]["frameCount"] = 8
		anims[STATE_WALK]["loop"] = true
		
	anims[STATE_RUN] = {}
		anims[STATE_RUN]["timing"] = 0.75
		anims[STATE_RUN]["frameCount"] = 8
		anims[STATE_RUN]["loop"] = true
		
	anims[STATE_FALL] = {}
		anims[STATE_FALL]["timing"] = 0.25
		anims[STATE_FALL]["frameCount"] = 4
		anims[STATE_FALL]["loop"] = false
		
	anims[STATE_JUMP] = {}
		anims[STATE_JUMP]["timing"] = 0.25
		anims[STATE_JUMP]["frameCount"] = 4
		anims[STATE_JUMP]["loop"] = false
		
	--it is worth noting here that we treat the swim animation like a looping run animation
	--technically, it's not, but it behaves that way with the timings for our purposes
	anims[STATE_SWIM] = {}
		anims[STATE_SWIM]["timing"] = 0.5
		anims[STATE_SWIM]["frameCount"] = 7 -- not 8. this is not a typo.
		anims[STATE_SWIM]["loop"] = true
		
	anims[STATE_SWIM_IDLE] = {}
		anims[STATE_SWIM_IDLE]["timing"] = 0.5
		anims[STATE_SWIM_IDLE]["frameCount"] = 1
		anims[STATE_SWIM_IDLE]["loop"] = true
	
	if anims[anim] then
		local timePerFrame = anims[anim].timing / anims[anim].frameCount
		local index = timeSpent / timePerFrame
		if anims[anim].loop then
			index = math.floor(index)
			index = index % anims[anim].frameCount
			index = index + 1
		else
			index = math.ceil(index)
			if index > anims[anim].frameCount then
				index = anims[anim].frameCount
			end
		end
		--sb.logInfo("index " .. tostring(index))
		--sb.logInfo("ts " .. tostring(timeSpent))
		--sb.logInfo("tpf " .. tostring(timePerFrame))
		return index
	end
	return 0
end

--indexed list in the following format
--	_mcontroller (object from the mcontroller hook script)
--  _lastKnownAnimationState (string)
--  _timeSpentInCurrentAnimation (float)
--
entityFullbrightComponentsCache = {}

--used to offset some of the drawable drift that occurs
cachedVelocity = { 0, 0 }

function cacheMController(mc_args)
	
	if not entityFullbrightComponentsCache[mc_args._entityId] then
		--sb.logInfo("Initializing new cache entry for entityId " .. tostring(mc_args._entityId))
		entityFullbrightComponentsCache[mc_args._entityId] = {}
		entityFullbrightComponentsCache[mc_args._entityId]._lastKnownAnimationState = STATE_UNKNOWN
		entityFullbrightComponentsCache[mc_args._entityId]._timeSpentInCurrentAnimation = 0
		entityFullbrightComponentsCache[mc_args._entityId]._image = "/assetmissing.png"
	end
	--sb.logInfo("updating cache entry")
	entityFullbrightComponentsCache[mc_args._entityId]._mcontroller = mc_args._mcontroller
	
	if mc_args._entityId == player.id() then
		cachedVelocity = mc_args._mcontroller._velocity
	end
	--for k, v in pairs(entityFullbrightComponentsCache) do
	--	sb.logInfo("Cache entry " .. k .. ": " .. tostring(v))
	--end
end

function renderFullbrightComponents(id, dt)

	--get last known mcontroller state
	--sb.logInfo("rendering for id: " .. tostring(id))
	local cacheEntry = entityFullbrightComponentsCache[id] --status.statusProperty("nicemice_mcontroller")
	
	--valid state, parse it
	if cacheEntry then
	
		--no point in rendering nothing
		if cacheEntry._image then
		
			local awa = cacheEntry._mcontroller
			if awa then
			
				--if our animation state changed, update our timings, because that's how we infer the current frame
				local currentAnimationState = inferCurrentStateFromMovementController(awa, id)
				world.debugText("%s",currentAnimationState,vec2.add({0,4},entity.position()),{255,255,0,255})
				if currentAnimationState ~= cacheEntry._lastKnownAnimationState then
					cacheEntry._timeSpentInCurrentAnimation = 0
					cacheEntry._lastKnownAnimationState = currentAnimationState
					--sb.logInfo(currentAnimationState)
				end

				--this is really wacky but it's the only option we've got for non-idle anims
				cacheEntry._timeSpentInCurrentAnimation = cacheEntry._timeSpentInCurrentAnimation + dt
				local frame = inferCurrentFrameFromTimeSpentInAnimationState(currentAnimationState,cacheEntry._timeSpentInCurrentAnimation)
				
				--get head fullbright directives, if any
				local directives = nicemice_getHeadFullbrightDirectives(id)
				if not directives then directives = "" end
				
				--sb.logInfo(directives)
				
				--get the idle x offset. for nicemice this will be -1 pixels for all idles except 1
				local offsetX = 0
				local baseOffsetY = 0.0625
				local offsetY = 0
				
				--handle offsets depending on anim state
				if currentAnimationState == STATE_IDLE then
					local idlePose = nicemice_getEntityIdleBodyFrame(id)
					if idlePose == "idle.1" then
						offsetX = 0
					else
						offsetX = -0.125
					end
				end
				
				if currentAnimationState == STATE_WALK then
					offsetX = 0
					local bobOffsets = { 0, -1, 0, 1, 0, -1, 0, 1 }
					offsetY = 0.125 * bobOffsets[frame]
				end
				
				if currentAnimationState == STATE_RUN then
					offsetX = 0.125
					local bobOffsets = { -1, 0, -1, -2, -1, 0, -1, -2 }
					offsetY = 0.125 + (0.125 * bobOffsets[frame])
				end
				
				if currentAnimationState == STATE_JUMP then
					offsetX = 0
				end
				
				if currentAnimationState == STATE_JUMP_CREST then
					offsetX = 0
				end
				
				if currentAnimationState == STATE_FALL then
					offsetX = 0
					offsetY = 0.125
				end
				
				if currentAnimationState == STATE_CROUCH then
					offsetX = 0.125
					offsetY = -0.25
				end
				
				if currentAnimationState == STATE_SWIM_IDLE then
					offsetX = 0.125
				end
				
				if currentAnimationState == STATE_SWIM then
					offsetX = 0.125
					local bobOffsets = { 0, -1, -2, -1, 0, 0, 0 }
					offsetY = (0.125 * bobOffsets[frame])
				end
				
				if currentAnimationState == STATE_SIT then
					
				end
				
				local facingDir = awa._facingDirection
				if facingDir < 0 then
					directives = directives .. "?flipx;"
				end
				
				--flip if appropriate
				offsetX = offsetX * facingDir
				
				--offset to entity location (for non-player entities)
				local delta = world.distance( world.entityPosition(id), entity.position() )
				
				--for non-player entities, moving around causes some drift. this attempts to correct that
				local cvx = (cachedVelocity[1] / 60)
				local cvy = (cachedVelocity[2] / 60)
				
				--but it's not necessary to correct for the player becuase they're attached to their own camera
				if id == player.id() then
					cvx = 0
					cvy = 0
				end
				
				localAnimator.addDrawable
				(
					{
						--image = "/items/armors/nicemice/costumes/gremlin/lofty_nicemice_gremlingoggles_fullbright.png:" .. currentAnimationState .. "." .. frame .. "?" .. directives,
						image = cacheEntry._image .. "?" .. directives,
						rotation = 0,
						position = 
						{ 
							delta[1] + offsetX - cvx, 
							delta[2] + baseOffsetY + offsetY - cvy
						},
						fullbright = true,
						centered = true,
						color = {255, 255, 255, 255}
					}, 
					"Npc+1"
				)
			end
		end
	end
end

function uncacheEntityFullbrightComponents(id)
	entityFullbrightComponentsCache[id] = nil
	cachedNPCItems[id] = nil
end

function setFullbrightComponentsCacheEntryImage(id, image)
	if entityFullbrightComponentsCache[id] then
		entityFullbrightComponentsCache._image = image
	else
		entityFullbrightComponentsCache[id] = 
		{
			_image = image,
			_lastKnownAnimationState = STATE_UNKNOWN,
			_timeSpentInCurrentAnimation = 0
		}
	end
end

--npcs are unlikely to swap their items very often so we cache them once every 60 sec
--	_itemCache
--	_lastCacheTime
cachedNPCItems = {}
function fetchNPCItems(id, dt)
	if not cachedNPCItems[id] then
		cachedNPCItems[id] = {}
		cachedNPCItems[id].timeSinceLastScan = 60
	end
	cachedNPCItems[id].timeSinceLastScan = cachedNPCItems[id].timeSinceLastScan + dt
	if cachedNPCItems[id].timeSinceLastScan >= 60 then
		cachedNPCItems[id].timeSinceLastScan = 0
		world.sendEntityMessage(id, "nicemice_npcItemsQuery", { _senderId = entity.id() } )
	end
end

function cacheNPCItems(args)
	if cachedNPCItems[args._senderId] then
		local slots = { "head", "headCosmetic", "chest", "chestCosmetic", "legs", "legsCosmetic", "back", "backCosmetic", "primary", "alt" }
		local doWeCareAboutAnyOfTheseItems = false
		for i, v in ipairs(slots) do
			cachedNPCItems[args._senderId][v] = args[v]
			--args[v] is going to look like this:
			--	name
			--	count
			--	parameters
			
			--grab the root config
			if args[v] then
				local conf = root.itemConfig( args[v].name )
				--should be:
				-- config
				-- directory
				-- parameters
				
				if conf ~= nil then
					if conf.config.nicemice_headFullbrightLayer then
						--sb.logInfo("This item has a fullbright head slot")
						doWeCareAboutAnyOfTheseItems = true
						setFullbrightComponentsCacheEntryImage( args._senderId, conf.config.nicemice_headFullbrightLayer )
					end
				end
			end
		end
		if doWeCareAboutAnyOfTheseItems then
			world.sendEntityMessage(args._senderId, "nicemice_mcontroller_subscribeMe", { _senderId = entity.id() } )
		else
			uncacheEntityFullbrightComponents(args._senderId)
		end
	end
end

local lastSensorSweep = 0
function scanForFullbrightEntities(dt)
	lastSensorSweep = lastSensorSweep + dt
	local scanRate = 3
	if lastSensorSweep > scanRate then
		lastSensorSweep = 0
		local crew = world.entityQuery(entity.position(), 100, { includedTypes = { "npc", "player" } } )
		for k, v in ipairs(crew) do
			if world.entityType(v) == "npc" then
				fetchNPCItems(v, scanRate)
			else
				world.sendEntityMessage(v, "nicemice_mcontroller_subscribeMe", { _senderId = entity.id() } )
			end
		end
	end
end

function renderFullbrightEntities(dt)
	localAnimator.clearDrawables()
	for k, v in pairs(entityFullbrightComponentsCache) do
		renderFullbrightComponents(k, dt)
	end
end

function update(dt)
	_update(dt)
	scanForFullbrightEntities(dt)
	renderFullbrightEntities(dt)
end

function uninit()
	_uninit()
	
end